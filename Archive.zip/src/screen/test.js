import React, { Component } from 'react';
import { ScrollView, StyleSheet, View, Text, ActivityIndicator, RefreshControl, TouchableOpacity } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
const test = () => {
	return (
		<ScrollView
				RefreshControl={
					<RefreshControl refreshing={this.state.refreshing} onRefresh={() => this.onRefresh()} title="" />
				}
				style={{ height:100 }}
			>
		<View
			style={{
				height: 200,
				borderRadius: 13,
				margin: 15
			}}
		><View style={{zIndex: 1,
            elevation: 2,
            shadowColor: '#ccc',
            shadowOffset: {
                width: 3,
                height: 3
            },
            shadowOpacity: .67,
            shadowRadius: 3.49,
            
            }}>
			<LinearGradient
				colors={[ '#6e80fe', '#a976fb', '#f36af9' ]}
				start={{ x: 0, y: 1 }}
				end={{ x: 1, y: 0 }}
				style={{
					borderRadius: 13,
					left: 0,
					right: 0,
					top: 0,
					zIndex: 1,
					elevation: 2,
                    height: 200,
                   
                    
				}}
			/>
            </View>
			<View
				style={{
					shadowColor: '#ccc',
					shadowOffset: {
						width: 3,
						height: 3
					},
					shadowOpacity: 0.37,
					shadowRadius: 2.49,
					elevation: 1,
					borderRadius: 13,
					zIndex: 0,
					elevate: 0,
					marginTop: -10,
					marginLeft: 15,
					marginRight: 15,
					height: 60,
					backgroundColor: 'white'
				}}
			/>
		</View>
		</ScrollView>
	);
};

export default test;
