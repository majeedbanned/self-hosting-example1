import React, { Component } from 'react';
import { createAppContainer } from 'react-navigation';

import { withNavigation } from 'react-navigation';
import {
	Picker,
	TextInput,
	Text,
	Button,
	Alert,
	View,
	StyleSheet,
	TouchableHighlight,
	TouchableNativeFeedback,
	TouchableOpacity,
	TouchableWithoutFeedback
} from 'react-native';
import * as yup from 'yup';
import { compose } from 'recompose';
import * as SQLite from 'expo-sqlite';
import { handleTextInput, withPickerValues, Formik } from 'formik';
import FormInput from '../component/FormInput';
import Lotte from '../components/lotte';
import NetInfo from '@react-native-community/netinfo';
import * as Network from 'expo-network';
import FormButton from '../component/FormButton';

import DropdownAlert from 'react-native-dropdownalert';
import { TextField, FilledTextField, OutlinedTextField } from 'react-native-material-textfield';
import * as Application from 'expo-application';
var MessageBarAlert = require('react-native-message-bar').MessageBar;
var MessageBarManager = require('react-native-message-bar').MessageBarManager;
import useResult from '../hooks/useResult';
//import { getUniqueId, getManufacturer } from 'react-native-device-info';
import Database from '../components/database';
import ErrorMessage from '../component/ErrorMessage';
import i18n from 'i18n-js';
import en from '../translations/en';
import fa from '../translations/fa';
import reactNativeExtraDimensionsAndroid from 'react-native-extra-dimensions-android';
import { HelloChandu, _getcount, getQuery, _query, _fetch, _connected } from '../components/DB';
import { region } from 'expo-localization';
import { red } from 'colorette';
import { ScrollView } from 'react-native-gesture-handler';
import { CallModal, CallModalUtil, connectCallModal } from '@fugood/react-native-call-modal';

i18n.locale = 'fa';
i18n.fallbacks = true;
let connected = false;
let ip = '';
let macaAress = '';
//import { useNavigation } from '@react-navigation/native';
// NetInfo.fetch().then(async (state) => {
// 	try {
// 		connected = state.isConnected;
// 		ip = await Network.getIpAddressAsync();
// 		macaAress = await Application.getIosIdForVendorAsync();
// 		//macaAress = await Network.getMacAddressAsync();
// 	} catch (error) {}
// });
class Appaa extends Component {
	/* #region constructor */
	constructor(props) {
		super(props);
		this.state = { isSubmitting: false, retUser: [] };
	}

	/* #endregion */

	loadAPI = async (username, password, schoolcode, adress, json) => {
		//await CallModalUtil.confirm('Sure to logout?');

		/* #region user exist  */
		let results = await Database.executeSql('select * from users where username=? and schoolcode=?', [
			username,
			schoolcode
		]);
		if (results.rows.length > 0) {
			this.dropDownAlertRef.alertWithType('warn', 'اخطار', 'این کاربر قبلا وارد شده است');
			console.log(results.rows);
			return;
		}
		/* #endregion */

		/* #region  check internet */
		let state = await NetInfo.fetch();
		//connected = state.isConnected;
		if (!state.isConnected) {
			// alertWithType parameters: type, title, message, payload, interval.
			// There are 4 pre-defined types: info, warn, success, error.
			// payload object with source property overrides image source prop. (optional)
			// interval overrides closeInterval prop. (optional)
			this.setState({ isSubmitting: false });
			this.dropDownAlertRef.alertWithType('warn', 'اخطار', 'لطفا دسترسی به اینترنت را چک کنید');
			return;
		}
		/* #endregion */

		this.setState({ isSubmitting: true });

		let uurl =
			'http://' +
			adress +
			':8080/pApi.asmx/ath?p=' +
			username +
			'`' +
			password +
			'`' +
			schoolcode +
			'`357611123qwe!@$';
		console.log(uurl);
		try {
			const response = await fetch(uurl);
			if (response.ok) {
				let retJson = await response.json();
				if (Object.keys(retJson).length == 0) {
					this.dropDownAlertRef.alertWithType('error', 'پیام', 'نام کاربری یا کلمه عبور اشتباه است');
					this.setState({
						isSubmitting: false
					});
					return;
				}
				////////// sccess
				this.setState({
					retUser: retJson,
					isSubmitting: false
				});
				this.dropDownAlertRef.alertWithType(
					'success',
					'پیام',
					this.state.retUser[0]['firstname'] + ' ' + this.state.retUser[0]['lastname'] + ' با موفقیت وارد شد '
				);
			}
		} catch (e) {
			this.dropDownAlertRef.alertWithType('error', 'پیام', 'خطادر دستیابی به اطلاعات');
			this.setState({
				isSubmitting: false
			});
			return;
		}

		console.log(this.state.retUser);
		const db = SQLite.openDatabase('db');
		db.transaction((tx) => {
			tx.executeSql(
				'insert into users (username,password,schoolcode,adress,firstname,lastname,schoolname,ttype) values (?,?,?,?,?,?,?,?)',
				[
					username,
					password,
					schoolcode,
					adress,
					this.state.retUser[0]['firstname'],
					this.state.retUser[0]['lastname'],
					this.state.retUser[0]['schoolname'],
					this.state.retUser[0]['utype']
				],
				(tx, rs) => {},
				(tx, err) => {
					console.log(err);
				}
			);
		});

		global.username = username;
		global.password = password;
		global.schoolcode = schoolcode;
		global.adress = 'http://192.168.1.12:8080';
		global.firstname = this.state.retUser[0]['firstname'];
		global.lastname = this.state.retUser[0]['lastname'];
		global.schoolname = this.state.retUser[0]['schoolname'];
		global.ttype = this.state.retUser[0]['utype'];
	};

	render() {
		console.log('ss');
		//const navigation = useNavigation();
		const { navigate } = this.props.navigation;
		//StackNavigator.navigate()
		const inputStyle = {
			borderWidth: 1,
			borderColor: '#bbb',
			padding: 12,
			direction: 'rtl',
			fontSize: 18,
			textAlign: 'center',
			borderRadius: 10,
			marginTop: 10
		};

		return (
			<View style={{ flex: 1, backgroundColor: '#f6fbff' }}>
				<ScrollView>
					<Formik
						style={{ backgroundColor: 'red' }}
						initialValues={{
							username: '1080687149',
							password: '1',
							schoolcode: '95100040',
							adress: '192.168.1.12'
						}}
						validateOnBlur={false}
						validateOnChange={false}
						// 	onSubmit={async (values, { resetForm }) => {
						// 		//await onSubmit(values)
						//   console.log('sdf');
						//   resetForm({username:''})
						// 	  }}

						onSubmit={(values) => {
							this.loadAPI(
								values['username'],
								values['password'],
								values['schoolcode'],
								values['adress'],
								JSON.stringify(values)
							);
							//resetForm();

							//Alert.alert(JSON.stringify(values));
							//}, 1000);
						}}
						validationSchema={yup.object().shape({
							username: yup.string().required('لطفا نام کاربری را وارد کنید'),
							password: yup.string().required('لطفا کلمه عبور  را وارد کنید'),
							schoolcode: yup.string().required('لطفا کد آموزشگاه را وارد کنید'),
							adress: yup.string().required('لطفا آدرس اینترنتی را وارد کنید')
						})}
					>
						{({
							formikProps,
							values,
							handleChange,
							isSubmitting,
							errors,
							setFieldTouched,
							touched,
							isValid,
							handleSubmit,
							resetForm
						}) => (
							<View style={styles.formContainer}>
								<OutlinedTextField
									baseColor="#7fc2f8"
									textColor="#0087f3"
									value={values.username}
									label={i18n.t('username')}
									keyboardType="numeric"
									formatText={this.formatText}
									onChangeText={handleChange('username')}
									//onSubmitEditing={this.onSubmit}
									style={styles.input}
									ref={this.fieldRef}
								/>
								<ErrorMessage errorValue={errors.username} />

								<OutlinedTextField
									baseColor="#7fc2f8"
									textColor="#0087f3"
									//value={values.password}
									label={i18n.t('password')}
									keyboardType="default"
									formatText={this.formatText}
									onChangeText={handleChange('password')}
									//onSubmitEditing={this.onSubmit}
									style={styles.input}
									ref={this.fieldRef}
								/>
								<ErrorMessage errorValue={errors.password} />

								<OutlinedTextField
									baseColor="#7fc2f8"
									textColor="#0087f3"
									value={values.schoolcode}
									label={i18n.t('schoolcode')}
									keyboardType="numeric"
									formatText={this.formatText}
									onChangeText={handleChange('schoolcode')}
									//onSubmitEditing={this.onSubmit}
									style={styles.input}
									ref={this.fieldRef}
								/>
								<ErrorMessage errorValue={errors.schoolcode} />

								<OutlinedTextField
									baseColor="#7fc2f8"
									textColor="#0087f3"
									backgroundColor="red"
									value={values.adress}
									label={i18n.t('adress')}
									keyboardType="default"
									formatText={this.formatText}
									onChangeText={handleChange('adress')}
									//onSubmitEditing={this.onSubmit}
									style={styles.input}
									ref={this.fieldRef}
								/>

								<ErrorMessage errorValue={errors.adress} />

								{/* <Button
							color="#3740FE"
							title="Submit"
							disabled={!isValid || isSubmitting}
							onPress={handleSubmit}
						/> */}

								<FormButton
									buttonColor="#1f9efd"
									borderColor="white"
									backgroundColor="#e3f1fc"
									buttonType="outline"
									onPress={handleSubmit}
									//disabled={!isValid }
									loading={this.state.isSubmitting}
									title={i18n.t('loginbtn')}
								/>
								<View style={{ marginTop: 40, backgroundColor: '#f6fbff' }}>
									<TouchableOpacity
										style={{ backgroundColor: '#f6fbff' }}
										onPress={() => navigate('qrscanner')}
										style={styles.burgerButton}
									>
										<Lotte />
									</TouchableOpacity>
								</View>
							</View>
						)}
					</Formik>
				</ScrollView>
				<DropdownAlert ref={(ref) => (this.dropDownAlertRef = ref)} />
			</View>
		);
	}
}

const styles = StyleSheet.create({
	formContainer: {
		flex: 1,
		marginTop: 40,
		padding: 40,
		backgroundColor: '#f6fbff'
	},
	input: {
		//borderColor:'red',

		marginTop: 0,
		textAlign: 'center',
		fontSize: 20
	}
});

console.disableYellowBox = true;
export default withNavigation(Appaa);
