import React, { Component } from 'react';
import { ScrollView, StyleSheet, View, Text, ActivityIndicator, RefreshControl, TouchableOpacity } from 'react-native';
import { FlatGrid } from 'react-native-super-grid';
import { useFonts } from '@use-expo/font';
import * as Font from 'expo-font';
import { withNavigation } from 'react-navigation';
import GLOBAL from './global';

//import { EvilIcons } from '@expo/vector-icons';
import { Ionicons } from '@expo/vector-icons';
//let items = [];
class menu extends Component {
	state = {
		isLoading: true,
		items: []
	};

	async componentDidMount() {
		await Font.loadAsync({
			iransans: require('./../../assets/IRANSansMobile.ttf'),
			iransansbold: require('./../../assets/IRANSansMobile_Bold.ttf')
		});

		// useFonts.loadAsync({
		// 	'iransans': require('./../../assets/IRANSansMobile.ttf'),
		//   });

		// let [fontsLoaded] = useFonts({
		// 	'iransans': require('./../../assets/IRANSansMobile.ttf'),
		//   });

		// this.getSurfaces();
		this.loadAPI();
	}
	_handleRefresh = () => {
		//this.loadAPI();
	};
	loadAPI = () => {
		this.setState({ isLoading: true });
		//console.log('fsafsfsafsfsdfs');
		fetch('http://192.168.1.12:8080/papi.asmx/mobileMainScreen?test=d')
			.then((response) => response.json())
			.then((responseText) => {
				//	this.setState({ items: responseText });
				this.setState({
					isLoading: false
				});
				//	console.log(this.state.items);
			})
			.catch((err) => {
				console.log('Error fetching the feed: ', err);
			});
	};

	onRefresh() {
		this.loadAPI();

		//this.setState({isFetching: true,},() => {this.getApiData();});
	}

	clickEventListener = (item) => {
		const { navigate } = this.props.navigation;
		navigate('test');
		//console.log(item.code);

		//Alert.alert('Message', 'Item clicked. ' + item.username);
	};

	render() {
		GLOBAL.screen1 = this;
		return (
			<React.Fragment>
				<ScrollView persistentScrollbar={true} horizontal={true} style={{ height: 242, flex: 0 }}>
					{this.state.isLoading && (
						<ActivityIndicator
							color={'red'}
							style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}
						/>
					)}
					{!this.state.isLoading && (
						<FlatGrid
							horizontal={true}
							// refreshControl={
							//   <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
							// }
							onRefresh={() => this.onRefresh()}
							refreshing={this.state.isLoading}
							itemDimension={100}
							items={this.state.items}
							style={styles.gridView}
							// staticDimension={300}
							// fixed
							// spacing={20}
							renderItem={({ item, index }) => (
								<View style={[ styles.itemContainer, { backgroundColor: '#fff' } ]}>
									{item.badge > 0 && <Text style={styles.badge}> {item.badge} </Text>}
									<View
										style={styles.shadow}
										style={{
											borderRadius: 15,
											flex: 1,
											width: '90%',
											padding: 15,
											backgroundColor: item.bkcolor,
											borderWidth: 0,
											borderColor: 'red'
										}}
									>
										<TouchableOpacity
											onPress={() => {
												this.clickEventListener(item);
											}}
											style={{ flex: 1 }}
										>
											<Ionicons
												name={item.icon}
												size={47}
												color={item.code}
												style={{
													shadowColor: item.bkcolor,
													flex: 1,
													alignSelf: 'center',
													paddingTop: 5,
													shadowColor: item.code,
													shadowOffset: {
														width: 3,
														height: 3
													},
													shadowOpacity: 0.37,
													shadowRadius: 2.49,
													elevation: 3
												}}
											/>
										</TouchableOpacity>
									</View>

									<Text style={styles.itemName}>{item.name}</Text>
									{/* <Text style={styles.itemCode}>{item.code}</Text> */}
								</View>
							)}
						/>
					)}
				</ScrollView>
			</React.Fragment>
		);
	}
}

const styles = StyleSheet.create({
	gridView: {
		//height:230,
		marginTop: 5,
		flex: 1,
		backgroundColor: '#fff'
	},
	itemContainer: {
		justifyContent: 'center',
		alignItems: 'center',
		borderRadius: 5,
		padding: 0,
		margin: 0,
		height: 103,
		width: 85,
		borderWidth: 0,
		borderColor: 'red'
	},
	itemName: {
		paddingTop: 0,
		fontFamily: 'iransans',
		fontSize: 13,
		color: '#000',
		fontWeight: '400'
	},
	shadow: {
		borderWidth: 1,
		borderColor: 'red'
	},
	itemCode: {
		fontWeight: '600',
		fontSize: 12,
		color: '#fff'
	},
	badge: {
		color: '#fff',
		position: 'absolute',
		zIndex: 10,
		top: 13,
		left: 10,
		padding: 1,
		overflow: 'hidden',
		backgroundColor: '#eb5757',
		borderRadius: 9,
		borderWidth: 0,
		borderColor: '#000'
	}
});
export default withNavigation(menu);
