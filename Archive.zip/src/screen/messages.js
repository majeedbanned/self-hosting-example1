import React, { Component } from 'react';
import { withNavigationFocus, NavigationEvents } from 'react-navigation';
//import SwiperFlatList from 'react-native-swiper-flatlist';
import * as Font from 'expo-font';
import { I18nManager, Platform, Button, Linking } from 'react-native';
import Swiper from 'react-native-swiper';
import GLOBAL from './global';
import * as FileSystem from 'expo-file-system';
import { Video } from 'expo-av';
import { Ionicons, AntDesign, Entypo } from '@expo/vector-icons';
import { userInfo, toFarsi, getHttpAdress } from '../components/DB';
import { Menu, MenuOptions, MenuOption, MenuTrigger } from 'react-native-popup-menu';
import {
	ActivityIndicator,
	StyleSheet,
	Text,
	View,
	Image,
	TouchableOpacity,
	FlatList,
	Dimensions,
	Alert,
	ScrollView,
	RefreshControl
} from 'react-native';
import NetInfo from '@react-native-community/netinfo';
import DropdownAlert from 'react-native-dropdownalert';
import { SearchBar } from 'react-native-elements';

import axios from 'axios';
I18nManager.allowRTL(true);
I18nManager.forceRTL(true);
import Modal from 'react-native-modal';
import SelectUser from '../screen/selectUser';
import { fromBinary } from 'uuid-js';
let hasScrolled = false;
class messages extends Component {
	constructor(props) {
		super(props);
		this.page = 1;
		this.state = {
			refreshing: false,
			isModalVisible: false,
			value: '',
			loading: false,
			isRefreshing: false, //for pull to refresh
			modalVisible: false,
			userSelected: [],
			data: []
		};
		this.arrayholder = [];
		let arch = '';
	}

	componentDidUpdate() {
		//console.log('update');
	}

	async componentDidMount() {
		await Font.loadAsync({
			iransans: require('./../../assets/IRANSansMobile.ttf')
		});
		this.arch = '';
		this.loadAPI(this.page, 'pull');
	}

	async onRefresh() {
		this.setState({ isRefreshing: true });
		let param = userInfo();
		let uurl = global.adress + '/pApi.asmx/getMessageList?currentPage=' + '1' + '&p=' + param;
		console.log(uurl);
		try {
			const response = await fetch(uurl);
			if (response.ok) {
				let retJson = await response.json();
				if (Object.keys(retJson).length == 0) {
					this.setState({
						isRefreshing: false
					});
					return;
				}

				let data = retJson;
				this.setState({
					data: data,
					isRefreshing: false
				});
				this.page = 1;
			}
		} catch (e) {
			this.dropDownAlertRef.alertWithType('error', 'پیام', 'خطادر دستیابی به اطلاعات');
			this.setState({
				isRefreshing: false
			});
			return;
		}
	}

	_handleLoadMore = () => {
		if (!this.state.isLoading) {
			this.page = this.page + 1;
			this.loadAPI(this.page, 'more');
		}
	};

	loadAPI = async (page, type) => {
		if (global.adress == 'undefined') {
			GLOBAL.main.setState({ isModalVisible: true });
		}
		/* #region  check internet */
		let state = await NetInfo.fetch();
		if (!state.isConnected) {
			this.dropDownAlertRef.alertWithType('warn', 'اخطار', 'لطفا دسترسی به اینترنت را چک کنید');
			return;
		}
		/* #endregion */

		this.setState({ loading: true });
		let param = userInfo();
		let uurl = global.adress + '/pApi.asmx/getMessageList?currentPage=' + page + '&p=' + param;
		try {
			const response = await fetch(uurl);
			if (response.ok) {
				let retJson = await response.json();
				if (Object.keys(retJson).length == 0) {
					this.setState({
						loading: false
					});
					return;
				}
				this.setState({
					data: page === 1 ? retJson : [ ...this.state.data, ...retJson ],

					loading: false
				});
			}
		} catch (e) {
			console.log('err');
			this.dropDownAlertRef.alertWithType('error', 'پیام', 'خطادر دستیابی به اطلاعات');
			this.setState({
				loading: false
			});
			return;
		}
	};

	renderHeader = () => {
		return (
			<SearchBar
				placeholder="Type Here..."
				lightTheme
				round
				onChangeText={(text) => this.searchFilterFunction(text)}
				autoCorrect={false}
				value={this.state.value}
			/>
		);
	};

	_renderFooter = () => {
		if (!this.state.isLoading) return null;
		return <ActivityIndicator style={{ color: 'red' }} size="large" />;
	};
	handleselect = () => {
		const { navigate } = this.props.navigation;
		console.log('SelectContact');
		navigate('SelectContact');
	};
	handleDownload = (data) => {
		if (data.split('.')[data.split('.').length - 1].toLowerCase() == 'jpg') {
			const { navigate } = this.props.navigation;
			navigate('Login');
		}
		if (data.split('.')[data.split('.').length - 1].toLowerCase() == 'pdf') {
			Linking.openURL('http://gahp.net/wp-content/uploads/2017/09/sample.pdf');
		}
	};
	// toggleModal = () => {
	// 	this.setState({ isModalVisible: !this.state.isModalVisible });
	// 	this.onRefresh();
	// };

	render() {
		GLOBAL.message = this;
		if (this.state.isLoading && this.page === 1) {
			return (
				<View
					style={{
						width: '100%',
						height: '100%'
					}}
				>
					<ActivityIndicator style={{ color: '#000' }} />
				</View>
			);
		}

		return (
			<View style={styles.container}>
				<FlatList
					ListFooterComponent={this._renderFooter}
					//onScroll={this.onScroll}
					initialNumToRender={10}
					onEndReachedThreshold={0.4}
					onEndReached={this._handleLoadMore.bind(this)}
					refreshControl={
						<RefreshControl refreshing={this.state.isRefreshing} onRefresh={this.onRefresh.bind(this)} />
					}
					style={styles.contentList}
					columnWrapperStyle={styles.listContainer}
					data={this.state.data}
					//ListHeaderComponent={this.renderHeader}
					keyExtractor={(item) => {
						return item.id;
					}}
					renderItem={({ item }) => {
						return (
							<View style={styles.card}>
								<View style={{ flexDirection: 'row', height: 40 }}>
									<Image
										style={styles.imageavatar}
										source={{ uri: getHttpAdress() + 'child/' + item.sender_ID + '.jpg' }}
									/>
									<View style={{ flexDirection: 'column', alignSelf: 'center', flex: 2 }}>
										<Text
											style={{
												paddingTop: 15,
												fontFamily: 'iransans',
												textAlign: 'left',
												alignSelf: 'stretch',
												padding: 8
											}}
										>
											{item.senderName}
										</Text>
										<Text
											style={{
												alignSelf: 'flex-start',
												fontSize: 11,
												marginTop: -10,
												color: '#aaa',
												fontFamily: 'iransans',
												paddingStart: 8,
												paddingTop: 5
											}}
										>
											{toFarsi(item.date + ' - ' + item.time)}
										</Text>
									</View>

									{/* <Menu>
										<MenuTrigger>
											<Ionicons name="md-more" size={29} style={styles.setting} />

											<Text style={{ fontSize: 40, fontWeight: 'bold' }}>⋮</Text>
										</MenuTrigger>
										<MenuOptions>
											<MenuOption onSelect={() => alert(`Save`)} text="Save" />
											<MenuOption onSelect={() => alert(`Delete`)}>
												<Text style={{ color: 'red' }}>Delete</Text>
											</MenuOption>
											<MenuOption
												onSelect={() => alert(`Not called`)}
												disabled={true}
												text="Disabled"
											/>
										</MenuOptions>
									</Menu> */}
								</View>
								<View style={{ flex: 1 }}>
									{item.elsaghi != '' && (
										<Swiper
											onIndexChanged={(index) => {
												console.log(item.elsaghi.split('|')[index]);
											}}
											paginationStyle={{
												flexDirection: Platform.OS === 'ios' ? 'row' : 'row-reverse'
											}}
											loop={false}
											style={styles.wrapper}
											showsButtons={false}
										>
											{item.elsaghi.split('|').map((data) => {
												let ext = data.split('.')[data.split('.').length - 1].toLowerCase();
												if (ext == 'jpg')
													return (
														<View key={data} style={styles.slide1}>
															<Image
																resizeMode="contain"
																style={{
																	width: '100%',
																	height: '100%',
																	borderWidth: 0
																}}
																source={{ uri: getHttpAdress() + 'media/' + data }}
															/>
														</View>
													);
												else if (ext == 'mp4') {
													return (
														<View key={data} style={styles.slide1}>
															<Video
																source={{
																	uri:
																		'http://d23dyxeqlo5psv.cloudfront.net/big_buck_bunny.mp4'
																}}
																rate={1.0}
																volume={1.0}
																isMuted={false}
																resizeMode="contain"
																isLooping
																style={{
																	width: '100%',
																	height: '100%',
																	borderWidth: 0
																}}
															/>
														</View>
													);
												} else
													return (
														<View key={data} style={styles.slide1}>
															<Text style={styles.text}>{data}</Text>
														</View>
													);
											})}
										</Swiper>
									)}

									<View style={styles.cardContent}>
										<View style={{ flexDirection: 'row', alignSelf: 'flex-end' }}>
											<TouchableOpacity
												onPress={() => {
													this.handleselect();
												}}
											>
												<Entypo name="forward" size={27} style={styles.forward} />
											</TouchableOpacity>
											<TouchableOpacity>
												<AntDesign name="message1" size={27} style={styles.massage} />
											</TouchableOpacity>
											<Ionicons size={27} style={styles.space} />

											{/* <Ionicons name="md-attach" size={33} style={styles.attach} /> */}

											{item.elsaghi != '' && (
												<View style={{ flexDirection: 'row' }}>
													{item.elsaghi.split('|').map((data) => {
														let ext = data
															.split('.')
															[data.split('.').length - 1].toLowerCase();

														if (ext == 'jpg')
															return (
																<TouchableOpacity
																	onPress={() => {
																		this.handleDownload(data);
																	}}
																>
																	<Ionicons
																		name="ios-image"
																		size={32}
																		color="#bbb"
																		style={{ marginLeft: 10 }}
																	/>
																</TouchableOpacity>
															);
														else if (ext == 'pdf')
															return (
																<TouchableOpacity
																	onPress={() => {
																		this.handleDownload(data);
																	}}
																>
																	<AntDesign
																		style={{ marginLeft: 10 }}
																		name="pdffile1"
																		size={30}
																		color="#bbb"
																	/>
																</TouchableOpacity>
															);
														else if (ext == 'xls' || ext == 'xlsx')
															return (
																<TouchableOpacity
																	onPress={() => {
																		this.handleDownload(data);
																	}}
																>
																	<AntDesign
																		style={{ marginLeft: 10 }}
																		name="exclefile1"
																		size={30}
																		color="#bbb"
																	/>
																</TouchableOpacity>
															);
														else
															return (
																<TouchableOpacity
																	onPress={() => {
																		this.handleDownload(data);
																	}}
																>
																	<Ionicons
																		name="md-attach"
																		size={35}
																		style={{ marginLeft: 10 }}
																		color="#bbb"
																	/>
																</TouchableOpacity>
															);
													})}
												</View>
											)}
										</View>
										<Text style={styles.name}>{item.title}</Text>
									</View>
								</View>
							</View>
						);
					}}
				/>
			</View>
		);
	}
}
export const { width, height } = Dimensions.get('window');
const styles = StyleSheet.create({
	heart: {
		flex: 1,
		color: '#aaa',
		alignSelf: 'center',
		paddingTop: 0
	},

	setting: {
		flex: 1,
		color: '#aaa',
		alignSelf: 'center',
		paddingTop: 9,
		marginEnd: 10
	},

	attach: {
		flex: 1,
		marginEnd: 13,
		color: '#aaa',
		alignSelf: 'center',
		paddingTop: 0
	},
	space: {
		flex: 5,
		paddingEnd: 10,
		color: '#aaa',

		alignSelf: 'flex-end'
	},
	message: {
		flex: 1,
		marginEnd: 13,
		color: '#aaa',
		alignSelf: 'center'
	},
	forward: {
		flex: 1,
		paddingEnd: 10,
		color: '#aaa',
		paddingStart: 15
	},

	container: {
		flex: 1,
		marginTop: 5,
		backgroundColor: global.backgroundColor
	},
	contentList: {
		flex: 1
	},
	cardContent: {
		marginRight: 20,
		marginTop: 10,
		alignItems: 'flex-start'
	},
	image: {
		width: 90,
		height: 90,
		borderRadius: 45,
		borderWidth: 2,
		borderColor: '#ebf0f7'
	},
	imageavatar: {
		width: 40,
		height: 40,
		borderRadius: 45,
		borderWidth: 1,
		borderColor: '#ccc'
	},
	imageavatar1: {
		width: 40,
		height: 40,
		alignSelf: 'center',
		borderRadius: 45,
		borderWidth: 1,
		borderColor: '#ccc'
	},
	card: {
		flex: 1,
		flexDirection: 'column',
		justifyContent: 'center',
		alignItems: 'stretch',
		shadowColor: '#00000021',
		shadowOffset: {
			width: 2,
			height: 1
		},
		shadowOpacity: 0.6,
		shadowRadius: 3,
		elevation: 1,

		marginLeft: 10,
		marginRight: 10,
		marginTop: 10,
		backgroundColor: 'white',
		padding: 10,

		borderRadius: 20
	},

	name: {
		fontSize: 14,
		flex: 1,
		fontFamily: 'iransans',
		textAlign: 'left',
		alignSelf: 'stretch',

		paddingStart: 10,
		color: 'green'
	},
	count: {
		fontSize: 14,
		flex: 1,
		alignSelf: 'center',
		color: '#6666ff'
	},
	followButton: {
		marginTop: 10,
		height: 35,
		width: 100,
		padding: 10,
		flexDirection: 'row',
		justifyContent: 'center',
		alignItems: 'center',
		borderRadius: 30,
		backgroundColor: 'white',
		borderWidth: 1,
		borderColor: '#dcdcdc'
	},
	followButtonText: {
		color: 'red',
		fontSize: 12
	},
	wrapper: {
		borderRadius: 20,
		marginTop: 10,
		flexDirection: Platform.OS === 'ios' ? 'row' : 'row-reverse',
		height: 320,
		paddingBottom: 40
	},
	slide1: {
		borderRadius: 20,
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: '#9DD6EB',
		marginBottom: 10
	},
	slide2: {
		borderRadius: 20,
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: '#97CAE5',
		marginBottom: 10
	},
	slide3: {
		borderRadius: 20,
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: '#92BBD9',
		marginBottom: 10
	},
	text: {
		color: '#fff',
		fontSize: 30,
		fontWeight: 'bold'
	}
});
export default withNavigationFocus(messages);
