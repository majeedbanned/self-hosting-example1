module.exports = {
	screen1: null,
	ActionBarImage: '',
	selectUser: null,
	main: null,
	message: null,
	exam: null,
	examAdd: null
};
