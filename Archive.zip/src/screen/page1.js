import React, { Component } from 'react';
import { View, ScrollView, TouchableOpacity, Text, RefreshControl } from 'react-native';
import ActionBarImage from '../components/ActionBarImage';
import Menu from '../screen/menu';
import GLOBAL from './global';
class page1 extends Component {
	state = {
		
		refreshing:false,
		data: []
	};
	static navigationOptions = {
		//To set the header image and title for the current Screen
		title: 'انتخاب کاربر',
		//Title
		headerLeft: <ActionBarImage />,
		//Image in Navigation Bar

		headerStyle: {
			backgroundColor: '#e3e3e3'
			//Background Color of Navigation Bar
		},

		headerTintColor: '#606070'
		//Text Color of Navigation Bar
	};
	handletouch = () => {
		console.log('sssssss');
		GLOBAL.ActionBarImage.setState({
			avatarSrc: 'http://192.168.1.12:8080/upload/95100040/child/1080687149.jpg'
		});
		console.log('sss');
	};
	onRefresh() {
		console.log('refresh');
		this.setState({ page: 1 });
		this.loadAPI(1);
	}


	async componentDidMount() {
		// await Font.loadAsync({
		// 	iransans: require('./../../assets/IRANSansMobile.ttf')
		// });

		
		this.loadAPI(1);
	}

	loadAPI = async (page) => {
		if (global.adress == 'undefined') {
			//this.setState({ refreshing: false });
		}

		/* #region  check internet */

		// let state = await NetInfo.fetch();
		// if (!state.isConnected) {
		// 	this.dropDownAlertRef.alertWithType('warn', 'اخطار', 'لطفا دسترسی به اینترنت را چک کنید');

		// 	return;
		// }
		/* #endregion */

		this.setState({ refreshing: true });

		let uurl = 'http://192.168.1.12:8080/papi.asmx/mobileMainScreen?test=d';
		console.log(uurl);
		try {
			const response = await fetch(uurl);
			if (response.ok) {
				

				let retJson = await response.json();
				console.log(retJson);
				if (Object.keys(retJson).length == 0) {
					this.setState({
						isSubmitting: false
					});
					return;
				}
				////////// sccess
				GLOBAL.screen1.setState({ items: retJson });
				console.log('nowww')
				this.setState({
					data: page === 1 ? retJson : [ ...this.state.data, ...retJson ],
					refreshing: false
				});
				console.log('data');
			}
		} catch (e) {
			this.dropDownAlertRef.alertWithType('error', 'پیام', 'خطادر دستیابی به اطلاعات');
			this.setState({
				isSubmitting: false
			});
			return;
		}
	};
	render() {
		return (
			<ScrollView
				refreshControl={
					<RefreshControl refreshing={this.state.refreshing} onRefresh={() => this.onRefresh()} title="" />
				}
			>
				<View>
					<Menu />
				</View>
			</ScrollView>
		);
	}
}

export default page1;
