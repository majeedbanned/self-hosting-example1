import React, { Component } from 'react';
import { withNavigation } from 'react-navigation';
import recyclerViewList1 from './recyclerViewList1';

import { View, ScrollView, StyleSheet, Image, FlatList, TouchableOpacity, Text, RefreshControl } from 'react-native';
import ActionBarImage from '../components/ActionBarImage';
import { userInfo, toFarsi, getHttpAdress } from '../components/DB';
import defaultStyles from '../config/styles';
import Menu from './menu';
import GLOBAL from './global';

const stories = ({ Navigation, Items, caption, ...rest }) => (
	<View
		style={[
			defaultStyles.shadow,
			{ borderColor: '#eee', borderBottomWidth: 1, backgroundColor: 'white', paddingTop: 5 }
		]}
	>
		<FlatList
			keyExtractor={(item, index) => String(index)}
			data={Items}
			horizontal
			// keyExtractor={(item) => {
			// 	return item.id;
			// }}
			renderItem={({ item, index }) => {
				return (
					<View
						style={[
							{
								justifyContent: 'center',
								alignItems: 'center',
								marginRight: 5,
								borderRadius: 15,
								backgroundColor: 'white'
							}
						]}
					>
						<View
							style={[
								{
									borderWidth: 0,
									borderRadius: 45,
									marginRight: 5,

									backgroundColor: '#f76d6d'
								}
							]}
						>
							<TouchableOpacity
								activeOpacity={0.7}
								onPress={() => {
									global.storyID = item.id;
									Navigation.navigate('recyclerViewList1');
								}}
							>
								<Image
									style={[
										styles.imageavatar,

										{
											borderWidth: 2,
											borderColor: 'white',
											margin: 2
										}
									]}
									source={{ uri: getHttpAdress() + 'media/' + item.image }}
								/>
							</TouchableOpacity>
						</View>

						<Text
							numberOfLines={1}
							style={[
								{
									width: 80,
									textAlign: 'center',
									fontFamily: 'iransans',
									fontSize: 12
								}
							]}
						>
							{item.name}
						</Text>
					</View>
				);
			}}
		/>
	</View>
);

const styles = StyleSheet.create({
	imageavatar: {
		width: 60,
		height: 60,
		borderRadius: 60,
		borderWidth: 0,
		borderColor: '#ccc'
	}
});
export default withNavigation(stories);
