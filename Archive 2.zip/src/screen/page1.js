import React, { Component } from 'react';
import { View, ScrollView, TouchableOpacity, Text, RefreshControl } from 'react-native';
import ActionBarImage from '../components/ActionBarImage';
import Menu from '../screen/menu';
import GLOBAL from './global';
import Birthday from '../screen/birthday';
import Stories from '../screen/stories';
class page1 extends Component {
	state = {
		refreshing: false,
		data: [],
		datamain: []
	};
	static navigationOptions = {
		//To set the header image and title for the current Screen
		title: 'انتخاب کاربر',
		//Title
		headerLeft: <ActionBarImage />,
		//Image in Navigation Bar

		headerStyle: {
			backgroundColor: '#e3e3e3'
			//Background Color of Navigation Bar
		},

		headerTintColor: '#606070'
		//Text Color of Navigation Bar
	};
	handletouch = () => {
		console.log('sssssss');
		GLOBAL.ActionBarImage.setState({
			avatarSrc: 'http://192.168.1.12:8080/upload/95100040/child/1080687149.jpg'
		});
		console.log('sss');
	};
	onRefresh() {
		console.log('refresh');
		this.setState({ page: 1 });
		this.loadAPI(1);
	}

	async componentDidMount() {
		// await Font.loadAsync({
		// 	iransans: require('./../../assets/IRANSansMobile.ttf')
		// });

		this.setState({
			stories: [
				{
					id: 1,
					image: '12.jpg',
					name: 'آزمایشگاه',
					caption: 'آزمایشگاه'
				},
				{
					id: 2,
					image: '13.jpg',
					name: 'آب بازی',
					caption: 'آب بازی'
				},
				{
					id: 3,
					image: '14.jpg',
					name: 'انتخابات دانش آموزی',
					caption: ''
				},
				{
					id: 4,
					image: '15.jpg',
					name: 'امتحانات',
					caption: 'امتحانات'
				},
				{
					id: 5,
					image: '16.jpg',
					name: 'کلاس آنلاین',
					caption: 'کلاس آنلاین'
				},
				{
					id: 6,
					image: '17.jpg',
					name: 'معلمین',
					caption: ''
				},
				{
					id: 7,
					image: '18.jpg',
					name: 'زمین بازی',
					caption: ''
				},
				{
					id: 8,
					image: '19.jpg',
					name: '',
					caption: ''
				}
			]
		});
		this.setState({
			datamain: [
				{
					caption: 'دانش آموزان برتر',

					items: [
						{
							studentcode: '1080687149',
							name: 'علی بهتاش',
							caption: ''
						},
						{
							studentcode: '1274593263',
							name: 'حامد ارشیان سالار پور',
							caption: ''
						},
						{
							studentcode: '214237683',
							name: 'هوشنگ ابتهاج',
							caption: ''
						},
						{
							studentcode: '45',
							name: 'محمود احمدی',
							caption: ''
						},
						{
							studentcode: '39',
							name: 'صمد بهرامی',
							caption: ''
						},
						{
							studentcode: '229',
							name: 'جمال شوریجه',
							caption: ''
						}
					]
				}
			]
		});

		this.loadAPI(1);
	}

	loadAPI = async (page) => {
		if (global.adress == 'undefined') {
			//this.setState({ refreshing: false });
		}

		/* #region  check internet */

		// let state = await NetInfo.fetch();
		// if (!state.isConnected) {
		// 	this.dropDownAlertRef.alertWithType('warn', 'اخطار', 'لطفا دسترسی به اینترنت را چک کنید');

		// 	return;
		// }
		/* #endregion */

		this.setState({ refreshing: true });

		let uurl = 'http://192.168.1.12:8080/papi.asmx/mobileMainScreen?test=d';
		console.log(uurl);
		try {
			const response = await fetch(uurl);
			if (response.ok) {
				let retJson = await response.json();
				console.log(retJson);
				if (Object.keys(retJson).length == 0) {
					this.setState({
						isSubmitting: false
					});
					return;
				}
				////////// sccess
				GLOBAL.screen1.setState({ items: retJson });
				//console.log('nowww');
				this.setState({
					data: page === 1 ? retJson : [ ...this.state.data, ...retJson ],
					refreshing: false
				});
				console.log('data');
			}
		} catch (e) {
			this.dropDownAlertRef.alertWithType('error', 'پیام', 'خطادر دستیابی به اطلاعات');
			this.setState({
				isSubmitting: false
			});
			return;
		}
	};
	render() {
		GLOBAL.page1 = this;
		if (this.state.datamain.length == 0) return null;
		//console.log(this.state.datamain[0].items);
		return (
			<ScrollView
				style={{
					backgroundColor: '#f8f8f8'
				}}
				refreshControl={
					<RefreshControl refreshing={this.state.refreshing} onRefresh={() => this.onRefresh()} title="" />
				}
			>
				<Stories Items={this.state.stories} Navigation={this.props.navigation} />
				<View>
					<Menu />
				</View>
				<View>
					<Birthday caption={this.state.datamain[0].caption} Items={this.state.datamain[0].items} />
				</View>
				<View>
					<Birthday caption={this.state.datamain[0].caption} Items={this.state.datamain[0].items} />
				</View>
				<View>
					<Birthday caption={this.state.datamain[0].caption} Items={this.state.datamain[0].items} />
				</View>
			</ScrollView>
		);
	}
}

export default page1;
