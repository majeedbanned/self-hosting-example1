import React, { Component } from 'react';
import { View, ScrollView, StyleSheet, Image, FlatList, TouchableOpacity, Text, RefreshControl } from 'react-native';
import ActionBarImage from '../components/ActionBarImage';
import { userInfo, toFarsi, getHttpAdress } from '../components/DB';
import defaultStyles from '../config/styles';
import Menu from '../screen/menu';
import GLOBAL from './global';

const birthday = ({ Items, caption, ...rest }) => (
	<View style={{ marginTop: 20, backgroundColor: 'white' }}>
		<View
			style={{
				marginTop: -18,
				marginStart: 15,
				marginBottom: 10,
				borderRadius: 20,
				borderWidth: 0,
				backgroundColor: '#f76d6d',
				alignSelf: 'flex-start',

				shadowColor: '#f76d6d',
				shadowOffset: {
					width: 3,
					height: 3
				},
				shadowOpacity: 0.37,
				shadowRadius: 2.49,
				elevation: 3
			}}
		>
			<Text
				style={{
					alignSelf: 'flex-start',
					padding: 7,
					color: 'white',
					borderWidth: 0,
					fontFamily: 'iransansbold',
					textAlign: 'left',
					paddingLeft: 10
				}}
			>
				{caption}
			</Text>
		</View>
		<FlatList
			keyExtractor={(item, index) => String(index)}
			data={Items}
			horizontal
			// keyExtractor={(item) => {
			// 	return item.id;
			// }}
			renderItem={({ item, index }) => {
				return (
					<View
						style={[
							defaultStyles.shadow,
							{
								justifyContent: 'center',
								alignItems: 'center',
								marginRight: 10,
								borderRadius: 15,
								backgroundColor: 'white'
							}
						]}
					>
						<View
							style={[
								{
									borderWidth: 0,
									marginRight: 5,
									borderRadius: 15,
									backgroundColor: 'white'
								}
							]}
						>
							<Image
								style={[
									styles.imageavatar,

									{
										margin: 5
									}
								]}
								source={{ uri: getHttpAdress() + 'child/' + item.studentcode + '.jpg' }}
							/>
						</View>

						<Text
							numberOfLines={1}
							style={[
								{
									width: 80,
									textAlign: 'center',
									fontFamily: 'iransans',
									fontSize: 12
								}
							]}
						>
							{item.name}
						</Text>
					</View>
				);
			}}
		/>
	</View>
);

const styles = StyleSheet.create({
	imageavatar: {
		width: 80,
		height: 96,
		borderRadius: 15,
		borderWidth: 0,
		borderColor: '#ccc'
	}
});
export default birthday;
