import React, { Component } from 'react';
import {StyleSheet,Text}from 'react-native';


const componentScreen =()=>{

    return <Text style={styles.textStyle} >h6i im majid</Text>
}

const styles= StyleSheet.create({

textStyle:{
    fontSize:39
}
})
export default componentScreen;
