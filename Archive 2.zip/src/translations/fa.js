export default {
    "username": "نام کاربری",
    "usernameErr":"لطفا نام کاربری را وارد نمایید",
    "password":"کلمه عبور",
    "passwordErr":"لطفا کلمه عبور را وارد نمایید",
    "schoolcode": "کدآموزشگاه",
    "adress": "آدرس اینترنتی",
    "loginbtn": "ورود",


  };