import React, { Component, useEffect } from 'react';
import { withNavigation } from 'react-navigation';
import { userInfo, toFarsi, getHttpAdress } from '../components/DB';
import { Ionicons } from '@expo/vector-icons';
import { StyleSheet, View, Text, Image, TouchableOpacity } from 'react-native';
import GLOBAL from '../screen/global';
class ActionBarImage extends Component {
	state = {
		avatarSrc: global.avatar == null ? 'a' : global.avatar
	};

	//if

	render() {
		GLOBAL.ActionBarImage = this;
		// this.setState({avatarSrc:global.avatar})
		//  global.avatar= this.state.avatarSrc;

		if (this.state.avatarSrc == '') {
			console.log('fucks=' + this.state.avatarSrc);
			return <View />;
		}

		console.log('uri=' + this.state.avatarSrc);
		const { navigate } = this.props.navigation;
		return (
			<TouchableOpacity
				onPress={() => {
					GLOBAL.main.setState({ isModalVisible: true });
				}}
			>
				<View style={{ flexDirection: 'row' }}>
					<Ionicons
						name="ios-heart-empty"
						size={30}
						style={{
							flex: 1,
							color: '#000',
							alignSelf: 'center',
							paddingEnd: 10
						}}
					/>

					<Image
						style={styles.imageavatar}
						source={{ uri: this.state.avatarSrc }}
						source={{ uri: getHttpAdress() + 'child/' + global.username + '.jpg' }}
					/>
				</View>
			</TouchableOpacity>
		);
	}
}

const styles = StyleSheet.create({
	imageavatar: {
		width: 30,
		height: 30,
		marginEnd: 10,
		borderRadius: 10,
		borderWidth: 1,
		borderColor: '#ccc'
	}
});

export default withNavigation(ActionBarImage);
