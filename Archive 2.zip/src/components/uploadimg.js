import React, { Component } from 'react';
import Icon from 'react-native-vector-icons/FontAwesome';
import AnimatedProgressWheel from 'react-native-progress-wheel';
import {
	Picker,
	TextInput,
	Text,
	Button,
	Alert,
	Image,
	View,
	StyleSheet,
	TouchableHighlight,
	TouchableNativeFeedback,
	TouchableOpacity,
	TouchableWithoutFeedback
} from 'react-native';
const uploadimg = ({ onimgPress, imageSourse, pgvisible, onDelete, progressnum }) => {
	return (
		<View
			style={{
				flexDirection: 'row',
				alignItems: 'center',
				justifyContent: 'space-evenly'
			}}
		>
			<View style={{ alignItems: 'center' }}>
				<TouchableOpacity style={{ alignItems: 'center' }} onPress={onimgPress}>
					<Image source={{ uri: imageSourse }} resizeMode="contain" style={styles.imgplaceholder} />
					<View style={styles.imgpp}>
						{pgvisible && (
							<AnimatedProgressWheel
								size={35}
								width={4}
								color={'blue'}
								progress={progressnum * 100}
								backgroundColor={'#ccc'}
							/>
						)}
						{!pgvisible && (
							<View>
								<Icon name="plus" size={24} color="#bbb" />
							</View>
						)}
					</View>
				</TouchableOpacity>
				{imageSourse != 'x' && (
					<TouchableOpacity style={{ alignItems: 'center' }} onPress={onDelete}>
						<Icon name="trash" size={24} color="#bbb" />
					</TouchableOpacity>
				)}
			</View>
		</View>
	);
};
const styles = StyleSheet.create({
	imgpp: {
		alignItems: 'center',
		justifyContent: 'center',
		flex: 1,
		borderWidth: 0,
		left: 0,
		top: 0,
		height: '100%',
		width: '100%',
		position: 'absolute'
	},
	imgplaceholder: {
		marginTop: 5,
		borderStyle: 'dashed',
		borderColor: '#ccc',
		borderWidth: 1,
		borderRadius: 15,
		height: 100,
		width: 80
	}
});
export default uploadimg;
