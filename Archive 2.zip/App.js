import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import HomeScreen from './src/screens/HomeScreen';
import ListScreen from './src/screens/listScreen';
import ActionBarImage from './src/components/ActionBarImage';
import componentScreen from './src/screens/componentScreen';
import TextScreen from './src/screens/textScreen';
import Craigslist from './src/screens/Craigslist';
import FlatListGrid from './src/screens/FlatListGrid';
import Mainmenu from './src/screens/mainmenu';
import React from 'react';
import SearchScreen from './src/screens/SearchScreen';
import ResultShowScreen from './src/screens/ResultShowScreen';
import scrollabletab from './src/screens/scrollabletab';
import FacebookExample from './src/screens/FacebookExample';
import paparButtomNavigator from './src/screens/paparButtomNavigator';
import qrscanner from './src/screens/qrscanner';
import galio from './src/screens/galio';
import stickytable from './src/screens/stickytable';
import persiancalendarpicker from './src/screens/calpicker';
import timeline from './src/screens/timeline';
import fixedtable from './src/screens/fixedtable';
import flatgrid from './src/screens/flatgrid';
import Lightbox from './src/screens/lightbox';
import Takeimage from './src/screens/takeimage';

import { Image, View, Text } from 'react-native';

import flatgridSection from './src/screens/flatgridSection';
//import lottie from './src/screens/lottie';
//recyclerViewList1;

import swipper from './src/screens/swipper';
import recyclerViewList1 from './src/screen/recyclerViewList1';
//import formik from './src/screens/formik';

import reactnativesnapcarousel from './src/screens/react-native-snap-carousel';

import modal from './src/screens/modal';
import timetable from './src/screens/timetable';
import Upload from './src/screens/upload';

import tcombform from './src/screens/tcombform';
import segmentedTab from './src/screens/segmentedTab';
import sheet from './src/screens/sheet';
import Audio from './src/screen/audio';
import barnameh from './src/screen/barnameh';

import Recorder from './src/screen/recorder';

import hookform from './src/screens/hookform';
//import btab2 from './src/screens/btab2';
import * as Font from 'expo-font';
import Login from './src/screen/Login';
import Forms from './src/screen/forms';

import Daftar from './src/screen/student/daftar';
import Workbook from './src/screen/workbook';

messageAdd;
import messageAdd from './src/screen/messageAdd';

import Main from './src/screen/main';
import Test from './src/screen/test';
import Splash from './src/screen/splash';

import cal from './src/screen/event';
import Classheet from './src/screen/Classheet';

import Exam from './src/screen/Exam';
import Workbookdt from './src/screen/workbook-detail';

import examAdd from './src/screen/examAdd';

import Logo from './src/screen/logo';

import selectuser from './src/screen/selectUser';
import { CallModal, CallModalUtil, connectCallModal } from '@fugood/react-native-call-modal';

import * as SQLite from 'expo-sqlite';
const db = SQLite.openDatabase('db');
import { I18nManager, AppRegistry } from 'react-native';
import GLOBAL from './src/screen/global';
import SelectContact from './src/screen/selectContact';

import { MenuProvider } from 'react-native-popup-menu';
I18nManager.allowRTL(true);
I18nManager.forceRTL(true);
const addDataToDb = () => {
	db.transaction((tx) => {
		//tx.executeSql('DROP TABLE users');

		tx.executeSql(
			`CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        password TEXT NOT NULL,
        schoolcode TEXT NOT NULL ,
		adress TEXT NOT NULL ,
		ttype TEXT NOT NULL ,
        firstname TEXT  NULL ,
		lastname TEXT  NULL ,
		localip TEXT  NULL ,
        schoolname TEXT  NULL 
		
		
		
		
      );`,
			[]
		);

		// tx.executeSql('insert into users (username, password, schoolcode,adress) values (?, ?, ? ,?)', [
		// 	'majid',
		// 	'pass',
		// 	'123',
		// 	'adress'
		// ]);

		// tx.executeSql(
		// 	'select * from users',
		// 	[],
		// 	(_, { rows: { _array } }) => console.log(_array),
		// 	() => console.log('error fetching')
		// );
	});
};
global.backgroundColor = '#f6fbff';
addDataToDb();
// db.transaction((tx) => {
// 	tx.executeSql('select * from users', [], (_, { rows: { _array } }) => {
// 		console.log(_array),
// 			() => {
// 				console.log('error fetching');
// 			};
// 	});
// });

db.transaction(function(txn) {
	txn.executeSql('select * from users', [], function(tx, res) {
		//console.log('item:', res.rows.length);
		if (res.rows.length != 0) {
			// console.log(res.rows.item(0));
		}
	});
});

const navigator = createStackNavigator(
	{
		Home: HomeScreen,
		Login: Login,
		Exam: Exam,
		Upload: Upload,
		SelectContact: SelectContact,
		selectuser: selectuser,
		Daftar: Daftar,
		modal: modal,
		Main: Main,
		Recorder: Recorder,
		Splash: Splash,
		Test: Test,
		Classheet: Classheet,
		// formik:formik,
		segmentedTab: segmentedTab,
		cal: cal,
		Audio: Audio,
		hookform: hookform,
		Logo: Logo,
		sheet: sheet,
		Workbook: Workbook,
		tcombform: tcombform,
		timetable: timetable,
		Workbookdt: Workbookdt,
		reactnativesnapcarousel: reactnativesnapcarousel,
		recyclerViewList1: recyclerViewList1,
		//// lottie:lottie,
		swipper: swipper,
		Takeimage: Takeimage,
		examAdd: examAdd,
		messageAdd: messageAdd,
		flatgrid: flatgrid,
		Forms: Forms,
		flatgridSection: flatgridSection,
		timeline: timeline,
		fixedtable: fixedtable,
		persiancalendarpicker: persiancalendarpicker,
		galio: galio,
		stickytable: stickytable,
		paparButtomNavigator: paparButtomNavigator,
		scrollabletab: scrollabletab,
		FacebookExample: FacebookExample,
		Mainmenu: Mainmenu,
		Lightbox: Lightbox,
		FlatListGrid: FlatListGrid,
		qrscanner: qrscanner,
		Craigslist: Craigslist,
		component: componentScreen,
		List: ListScreen,
		barnameh: barnameh,
		Textscr: TextScreen,
		SearchScreen: SearchScreen,
		ResultShow: ResultShowScreen
	},
	{
		initialRouteName: 'Main',
		defaultNavigationOptions: {
			headerTitle: <Image source={require('./assets/images/logo.png')} />,

			headerRight: () => <ActionBarImage />,

			headerBackTitle: 'بازگشت',
			headerBackTitleStyle: { color: 'black', fontSize: 15, fontFamily: 'iransans' },
			headerTitleStyle: {
				//fontWeight: 'bold'
				//fontFamily: 'iransans'
				//color:'red'
			},

			//headerTintColor: 'red',
			//header: null,
			//headerBackTitle: 'some label',
			navigationOptions: {
				title: 'انتخاب کاربر',
				//Title
				//	headerRight: <ActionBarImage />,
				//Image in Navigation Bar

				headerStyle: {
					backgroundColor: '#e3e3e3'
					//Background Color of Navigation Bar
				},

				headerTintColor: '#606070'
			}
		}
	}
);

const AppContainer = createAppContainer(navigator);
export default class App extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			fontLoaded: false
		};
	}

	async componentDidMount() {
		await Font.loadAsync({
			iransans: require('./assets/IRANSansMobile.ttf'),
			iransansbold: require('./assets/IRANSansMobile_Bold.ttf')
		});

		this.setState({ fontLoaded: true });
	}
	render() {
		const { fontLoaded } = this.state;
		global.username = '1080687149';
		global.password = '1';
		global.schoolcode = '95100040';
		global.adress = 'http://192.168.1.12:8080';
		global.firstname = 'ali';
		global.lastname = 'nazari';
		global.schoolname = 'taban';
		global.ttype = 'student';
		if (!fontLoaded)
			return (
				<View style={{ flex: 1 }}>
					<Text>init</Text>
				</View>
			);
		else
			return (
				<MenuProvider>
					<AppContainer />
				</MenuProvider>
			);
	}
}

//@connectCallModal
//class App extends React.Component {}
AppRegistry.registerComponent('App', () => App);
//export default createAppContainer(navigator);
